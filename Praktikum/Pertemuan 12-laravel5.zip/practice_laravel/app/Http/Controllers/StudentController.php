<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Student;
use DataTables;

class StudentController extends Controller
{
    public function index()
    {
        $data['students'] = Student::all();
        return view('student', $data);
    }

    public function create()
    {
        $data['gender'] = ["L", "P"];
        $data['departement'] = ["S1 RPL", "S1 Informatika", "S1 Sistem Informasi"];
        return view('studentTambah', $data);
    }

    public function store()
    {
        $student = new Student;
        $student->nim = request('nim');
        $student->name = request('name');
        $student->gender = request('gender');
        $student->departement = request('departement');
        $student->address = request('address');
        $student->save();

        return redirect() -> back() -> with('pesan', "Berhasil input data");
    }

    public function edit($id)
    {
        $data['student'] = Student::find($id);
        $data['gender'] = ["L", "P"];
        $data['departement'] = ["S1 RPL", "S1 Informatika", "S1 Sistem Informasi"];

        // $data['student'] = Student::where('nim', $id) -> first();
        return view('studentEdit', $data);
    }

    public function update(Request $request, $id)
    {
        $student = Student::find($id);
        $student->nim = request('nim');
        $student->name = request('name');
        $student->gender = request('gender');
        $student->departement = request('departement');
        $student->address = request('address');
        $student->save();

        return redirect() -> back() -> with('pesan', "Berhasil input data");
    }

    public function destroy($id)
    {
        $student = Student::find($id);
        $student->delete();

        return redirect() -> back() -> with('pesan', "Berhasil hapus data");
    }

    public function data(Request $request){
        if ($request->ajax()) {
            $data = Student::all();
            return Datatables::of($data)
                    ->addIndexColumn()
                    ->addColumn('action', function($row) {
                        $btn = '
                                <div class="text-center">
                                    <div class="btn-group">
                                          <a href="'.route('student.edit',['id'=> $row->id]).'" class="edit btn btn-success btn-sm">Edit</a>
                                          <a href="'.route('student.data.destroy',['id'=> $row->id]).'" class="btn btn-danger btn-sm">Hapus</a>
                                    </div>
                               </div>

                            ';
                        return $btn;
                    })
                    ->rawColumns(['action'])
                    ->make(true);
        }
        return view('student_data');
    }
}
