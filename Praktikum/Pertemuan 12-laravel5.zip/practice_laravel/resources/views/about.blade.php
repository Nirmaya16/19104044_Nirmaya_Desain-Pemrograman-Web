@extends('template.base')

@section('content')
    <h1>
        About   
    </h1>
    <p>Ini adalah praktikum Desain dan Pemrograman Web yang mempelajari Framework PHP yaitu Laravel</p>
@endsection